module com.example.hasan {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.hasan to javafx.fxml;
    exports com.example.hasan;
}