package com.example.hasan;

import javafx.application.Application;
import javafx.scene.Camera;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Box;
import javafx.stage.Stage;

public class Bookshelf extends Application {

    private static final int WIDTH = 1400;
    private static final int HEIGHT = 800;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Group bookshelfGroup = new Group();

        // Create vertical posts
        Box post1 = new Box(10, 300, 10);
        post1.setTranslateX(-200);
        post1.setMaterial(new javafx.scene.paint.PhongMaterial(Color.SADDLEBROWN)); // Set wood color
        bookshelfGroup.getChildren().add(post1);

        Box post2 = new Box(10, 300, 10);
        post2.setTranslateX(200);
        post2.setMaterial(new javafx.scene.paint.PhongMaterial(Color.SADDLEBROWN)); // Set wood color
        bookshelfGroup.getChildren().add(post2);

        // Create horizontal shelves
        Box shelf1 = new Box(400, 10, 100);
        shelf1.setTranslateY(150);
        shelf1.setMaterial(new javafx.scene.paint.PhongMaterial(Color.SADDLEBROWN)); // Set wood color
        bookshelfGroup.getChildren().add(shelf1);

        Box shelf2 = new Box(400, 10, 100);
        shelf2.setTranslateY(50);
        shelf2.setMaterial(new javafx.scene.paint.PhongMaterial(Color.SADDLEBROWN)); // Set wood color
        bookshelfGroup.getChildren().add(shelf2);

        Box shelf3 = new Box(400, 10, 100);
        shelf3.setTranslateY(-50);
        shelf3.setMaterial(new javafx.scene.paint.PhongMaterial(Color.SADDLEBROWN)); // Set wood color
        bookshelfGroup.getChildren().add(shelf3);

        Box shelf4 = new Box(400, 10, 100);
        shelf4.setTranslateY(-150);
        shelf4.setMaterial(new javafx.scene.paint.PhongMaterial(Color.SADDLEBROWN)); // Set wood color
        bookshelfGroup.getChildren().add(shelf4);

        Camera camera = new PerspectiveCamera();
        Scene scene = new Scene(bookshelfGroup, WIDTH, HEIGHT);
        scene.setFill(Color.WHITE);
        scene.setCamera(camera);

        bookshelfGroup.setTranslateX(WIDTH / 2);
        bookshelfGroup.setTranslateY(HEIGHT / 2);

        primaryStage.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()) {
                case W:
                    bookshelfGroup.setTranslateZ(bookshelfGroup.getTranslateZ() + 100);
                    break;
                case S:
                    bookshelfGroup.setTranslateZ(bookshelfGroup.getTranslateZ() - 100);
                    break;
            }
        });

        primaryStage.setTitle("3D Bookshelf");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
