package com.example.hasan;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Door2D extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create a root group to hold all elements
        Group root = new Group();

        // Solid color for the door
        Color doorColor = Color.SADDLEBROWN; // You can adjust the color as needed

        // Create the door panel with the specified color
        Rectangle doorPanel = new Rectangle(80, 200); // Adjust dimensions as needed
        doorPanel.setFill(doorColor);
        doorPanel.setX(210); // X position of the door panel
        doorPanel.setY(100); // Y position of the door panel

        // Door frame - adjust the position and dimensions relative to the door panel
        Rectangle doorFrame = new Rectangle(90, 210); // Adjust dimensions as needed
        doorFrame.setFill(Color.SADDLEBROWN); // You can adjust the color as needed
        doorFrame.setX(doorPanel.getX() - 5); // Adjust the X position to create a frame around the door panel
        doorFrame.setY(doorPanel.getY() - 5); // Adjust the Y position to create a frame around the door panel

        // Add all components to the root group
        root.getChildren().addAll(doorPanel, doorFrame);

        // Set up the scene and stage
        Scene scene = new Scene(root, 500, 400); // Window size
        primaryStage.setTitle("2D Door in JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
