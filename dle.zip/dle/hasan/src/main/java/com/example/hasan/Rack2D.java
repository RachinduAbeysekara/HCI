package com.example.hasan;
import javafx.application.Application;
import javafx.scene.Camera;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.stage.Stage;

public class Rack2D extends Application {

    private static final int WIDTH = 1400;
    private static final int HEIGHT = 800;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Group rackGroup = new Group();

        // Create vertical posts
        PhongMaterial woodMaterial = new PhongMaterial();
        woodMaterial.setDiffuseColor(Color.SADDLEBROWN); // Change wood color here

        Box post1 = new Box(10, 300, 10);
        post1.setTranslateX(-50);
        post1.setMaterial(woodMaterial); // Apply wood material
        rackGroup.getChildren().add(post1);

        Box post2 = new Box(10, 300, 10);
        post2.setTranslateX(50);
        post2.setMaterial(woodMaterial); // Apply wood material
        rackGroup.getChildren().add(post2);

        // Create horizontal shelves
        Box shelf1 = new Box(100, 10, 100);
        shelf1.setTranslateY(150);
        shelf1.setMaterial(woodMaterial); // Apply wood material
        rackGroup.getChildren().add(shelf1);

        Box shelf2 = new Box(100, 10, 100);
        shelf2.setTranslateY(50);
        shelf2.setMaterial(woodMaterial); // Apply wood material
        rackGroup.getChildren().add(shelf2);

        Box shelf3 = new Box(100, 10, 100);
        shelf3.setTranslateY(-50);
        shelf3.setMaterial(woodMaterial); // Apply wood material
        rackGroup.getChildren().add(shelf3);

        Box shelf4 = new Box(100, 10, 100);
        shelf4.setTranslateY(-150);
        shelf4.setMaterial(woodMaterial); // Apply wood material
        rackGroup.getChildren().add(shelf4);

        Camera camera = new PerspectiveCamera();
        Scene scene = new Scene(rackGroup, WIDTH, HEIGHT);
        scene.setFill(Color.WHITE);
        scene.setCamera(camera);

        rackGroup.setTranslateX(WIDTH / 2);
        rackGroup.setTranslateY(HEIGHT / 2);

        primaryStage.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()) {
                case W:
                    rackGroup.setTranslateZ(rackGroup.getTranslateZ() + 100);
                    break;
                case S:
                    rackGroup.setTranslateZ(rackGroup.getTranslateZ() - 100);
                    break;
            }
        });

        primaryStage.setTitle("3D Rack");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
