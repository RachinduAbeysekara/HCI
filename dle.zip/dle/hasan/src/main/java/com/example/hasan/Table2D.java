package com.example.hasan;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Table2D extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create a root group to hold all elements
        Group root = new Group();

        // Solid color for the table
        Color tableColor = Color.SADDLEBROWN;

        // Create the table components with the table color
        Rectangle tabletop = new Rectangle(200, 100); // Adjust dimensions as needed
        tabletop.setFill(tableColor);
        tabletop.setX(150); // X position of the tabletop
        tabletop.setY(200); // Y position of the tabletop

        Rectangle leg1 = new Rectangle(20, 80); // Adjust dimensions as needed
        leg1.setFill(tableColor);
        leg1.setX(tabletop.getX() + 10); // X position of leg1
        leg1.setY(tabletop.getY() + tabletop.getHeight());

        Rectangle leg2 = new Rectangle(20, 80); // Adjust dimensions as needed
        leg2.setFill(tableColor);
        leg2.setX(tabletop.getX() + tabletop.getWidth() - leg2.getWidth() - 10); // X position of leg2
        leg2.setY(tabletop.getY() + tabletop.getHeight());

        // Add all components to the root group
        root.getChildren().addAll(tabletop, leg1, leg2);

        // Set up the scene and stage
        Scene scene = new Scene(root, 500, 400); // Window size
        primaryStage.setTitle("2D Table in JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

