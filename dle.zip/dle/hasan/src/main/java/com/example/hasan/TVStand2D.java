package com.example.hasan;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class TVStand2D extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create a root group to hold all elements
        Group root = new Group();

        // Solid color for the TV stand
        Color standColor = Color.SADDLEBROWN;

        // Create the TV stand components with the specified color
        Rectangle base = new Rectangle(150, 20); // Adjust dimensions as needed
        base.setFill(standColor);
        base.setX(200); // X position of the base
        base.setY(300); // Y position of the base

        Rectangle leg1 = new Rectangle(20, 200); // Adjust dimensions as needed
        leg1.setFill(standColor);
        leg1.setX(base.getX());
        leg1.setY(base.getY() - leg1.getHeight());

        Rectangle leg2 = new Rectangle(20, 200); // Adjust dimensions as needed
        leg2.setFill(standColor);
        leg2.setX(base.getX() + base.getWidth() - leg2.getWidth());
        leg2.setY(base.getY() - leg2.getHeight());

        // Add all components to the root group
        root.getChildren().addAll(base, leg1, leg2);

        // Set up the scene and stage
        Scene scene = new Scene(root, 500, 400); // Window size
        primaryStage.setTitle("2D TV Stand in JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

