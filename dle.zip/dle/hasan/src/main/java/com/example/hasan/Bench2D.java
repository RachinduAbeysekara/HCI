package com.example.hasan;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Bench2D extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create a root group to hold all elements
        Group root = new Group();


        // Solid color for the bench
        Color woodColor = Color.SADDLEBROWN;

        // Create the bench components with the wood color
        Rectangle seat = new Rectangle(300, 30); // Adjust dimensions as needed
        seat.setFill(woodColor);
        seat.setX(100); // X position of the seat
        seat.setY(250); // Y position of the seat

        Rectangle backrest = new Rectangle(280, 80); // Adjust dimensions as needed
        backrest.setFill(woodColor);
        backrest.setX(seat.getX() + (seat.getWidth() - backrest.getWidth()) / 2); // Centered on the seat
        backrest.setY(seat.getY() - backrest.getHeight()); // Above the seat

        // Bench legs - adjust the position according to the seat's position
        Rectangle leg1 = new Rectangle(20, 50); // Adjust dimensions as needed
        leg1.setFill(woodColor);
        leg1.setX(seat.getX());
        leg1.setY(seat.getY() + seat.getHeight());

        Rectangle leg2 = new Rectangle(20, 50); // Adjust dimensions as needed
        leg2.setFill(woodColor);
        leg2.setX(seat.getX() + seat.getWidth() - leg2.getWidth());
        leg2.setY(seat.getY() + seat.getHeight());

        // Add all components to the root group
        root.getChildren().addAll(seat, backrest, leg1, leg2);

        // Set up the scene and stage
        Scene scene = new Scene(root, 500, 400); // Window size
        primaryStage.setTitle("2D Bench in JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
